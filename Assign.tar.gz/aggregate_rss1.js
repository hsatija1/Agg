var  async = require('async');
var xml2js = require("xml2js");
var aggregatednews;

function aggregate(rss1,rss2) {
     console.log("in aggregate--------");  
     
     var parser = new xml2js.Parser();
          parser.parseString(rss1.join(""), function (err, result) {
                
                result.rss.channel[0].item = result.rss.channel[0].item.slice(0,10);
                delete result.rss.channel[0]["atom:link"];
                delete result.rss.channel[0].image;
                delete result.rss.channel[0].language;
                delete result.rss.channel[0].copyright;
                delete result.rss.channel[0].lastBuildDate;
                delete result.rss.channel[0].category;
                delete result.rss.channel[0].ttl;
                result.rss.channel[0].title = "Aggregated News - BBC and SKY";
                result.rss.channel[0].link = "test_url";
                result.rss.channel[0].description = "The latest top 10 stories from the Home section of BBC and SKY News web site.";
                
                parser.parseString(rss2.join(""), function (err, result2) {
                     
                     result2.rss.channel[0].item = result2.rss.channel[0].item.slice(0,10);
                     result.rss.channel[0].item.push.apply(result.rss.channel[0].item, result2.rss.channel[0].item)
                     var itemArray = result.rss.channel[0].item;
                     console.log("items total---------:"+ itemArray.length);
                     var builder = new xml2js.Builder();
                     aggregatednews = builder.buildObject(result);
                });
                
            });
      

};

function getAggregatedNews() {
  return(aggregatednews);
}



module.exports.aggregate = aggregate;
module.exports.getAggregatedNews = getAggregatedNews;
